// Happi-El PhotoRevive — vérification et consommation des codes d'accès (quota par offre)
// Variables d'environnement requises : AIRTABLE_TOKEN, AIRTABLE_BASE_ID
const BASE = process.env.AIRTABLE_BASE_ID;
const TOKEN = process.env.AIRTABLE_TOKEN;
const TABLE = "Codes";
const json = (s, b) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json", "Cache-Control": "no-store, no-cache, must-revalidate" } });

async function trouverEnregistrement(code) {
  const url = `https://api.airtable.com/v0/${BASE}/${encodeURIComponent(TABLE)}?filterByFormula=${encodeURIComponent(`UPPER({Code})="${String(code).toUpperCase().replace(/"/g, '')}"`)}&maxRecords=1`;
  const r = await fetch(url, { headers: { Authorization: "Bearer " + TOKEN } });
  if (!r.ok) return null;
  const j = await r.json();
  return j.records && j.records[0] ? j.records[0] : null;
}

function evaluer(rec) {
  const f = rec.fields;
  const quota = Number(f.Quota || 0);
  const utilise = Number(f.Utilise || 0);
  const restant = Math.max(0, quota - utilise);
  const expire = f.Expire ? new Date(f.Expire + "T23:59:59") : null;
  const expireDepasse = expire ? expire < new Date() : false;
  const valide = restant > 0 && !expireDepasse;
  return { valide, restant, quota, expireDepasse, offre: f.Offre || "", nom: f.Client || "", expire: f.Expire || "" };
}

export default async (req) => {
  if (req.method !== "POST") return json(405, { ok: false });
  if (!BASE || !TOKEN) return json(500, { ok: false, erreur: "airtable_non_configure" });

  let body;
  try { body = await req.json(); } catch { return json(400, { ok: false }); }
  const code = String(body.code || "").trim();
  const action = body.action === "consommer" ? "consommer" : "verifier";
  if (!code) return json(400, { ok: false, erreur: "code_manquant" });

  const rec = await trouverEnregistrement(code);
  if (!rec) return json(404, { ok: false, erreur: "code_invalide" });

  const etat = evaluer(rec);
  if (!etat.valide) {
    return json(403, { ok: false, erreur: etat.expireDepasse ? "code_expire" : "quota_epuise", ...etat });
  }

  if (action === "verifier") {
    return json(200, { ok: true, ...etat });
  }

  // action === "consommer" : on incrémente Utilise de 1, avec re-vérification pour éviter une double
  // consommation en cas d'appels quasi simultanés (protection simple, pas un verrou distribué).
  const relu = await trouverEnregistrement(code);
  const etatRelu = evaluer(relu);
  if (!etatRelu.valide) {
    return json(403, { ok: false, erreur: etatRelu.expireDepasse ? "code_expire" : "quota_epuise", ...etatRelu });
  }
  const nouveauUtilise = Number(relu.fields.Utilise || 0) + 1;
  const nouveauRestant = etatRelu.quota - nouveauUtilise;
  const patch = await fetch(`https://api.airtable.com/v0/${BASE}/${encodeURIComponent(TABLE)}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + TOKEN },
    body: JSON.stringify({
      records: [{ id: relu.id, fields: { Utilise: nouveauUtilise, Statut: nouveauRestant <= 0 ? "Épuisé" : "Actif" } }]
    })
  });
  if (!patch.ok) return json(502, { ok: false, erreur: "maj_echouee" });

  return json(200, { ok: true, restant: Math.max(0, nouveauRestant), offre: etatRelu.offre, nom: etatRelu.nom, expire: etatRelu.expire });
};

// 10 tentatives/minute/IP : confortable pour un client qui se trompe de frappe,
// bien trop lent pour scanner l'espace des codes valides.
export const config = { path: "/api/acces", rateLimit: { windowLimit: 10, windowSize: 60, aggregateBy: ["ip"] } };
