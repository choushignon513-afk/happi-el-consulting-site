// Happi-El PhotoRevive — restylage studio professionnel via Nano Banana 2 (Gemini 3.1 Flash Image)
// Clé API : variable d'environnement GEMINI_API_KEY (configurée sur Netlify, jamais dans ce fichier)
const MODEL = "gemini-3.1-flash-image-preview";
const MAX_B64 = 6_000_000; // ~4,5 Mo d'image d'entrée max

const PROMPT_DEFAUT = `Transform this portrait into a professional studio photograph, in the style of a high-end editorial headshot:
- Replace the background with a smooth, softly textured neutral gray studio backdrop
- Add dramatic, professional studio lighting (soft key light with gentle directional shadow)
- Render skin with natural, sharp, realistic texture and visible pores — never smooth, plastic, or airbrushed
- Keep the person's facial identity, facial structure, expression, skin tone, hairstyle and clothing EXACTLY as in the original photo — do not change who they are or their features
- Photorealistic, high resolution, magazine-quality color grading, warm and rich tones
Do not add any text, watermark, or logo to the image.`;

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store, no-cache, must-revalidate" } });

export default async (req) => {
  if (req.method !== "POST") return json(405, { ok: false });
  const ACCESS = process.env.STYLIZE_ACCESS_TOKEN;
  if (ACCESS && req.headers.get("x-access-token") !== ACCESS) return json(401, { ok: false, erreur: "acces_refuse" });
  const KEY = process.env.GEMINI_API_KEY;
  if (!KEY) return json(500, { ok: false, erreur: "cle_gemini_absente" });

  let body;
  try { body = await req.json(); } catch { return json(400, { ok: false, erreur: "json" }); }
  const image = typeof body?.image === "string" ? body.image : "";
  const mimeType = typeof body?.mimeType === "string" ? body.mimeType : "image/jpeg";
  const prompt = typeof body?.prompt === "string" && body.prompt.trim() ? body.prompt : PROMPT_DEFAUT;
  if (!image || image.length > MAX_B64) return json(400, { ok: false, erreur: "image" });

  let r;
  try {
    r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "x-goog-api-key": KEY, "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }, { inlineData: { mimeType, data: image } }] }],
        generationConfig: { responseModalities: ["IMAGE"], imageConfig: { imageSize: "2K" } }
      })
    });
  } catch (e) {
    return json(502, { ok: false, erreur: "reseau_gemini", detail: String(e && e.message || e) });
  }

  let data;
  try { data = await r.json(); } catch { return json(502, { ok: false, erreur: "reponse_illisible" }); }

  if (!r.ok) {
    return json(502, { ok: false, erreur: "gemini_refuse", statut: r.status, detail: (data && data.error && data.error.message) || JSON.stringify(data).slice(0, 300) });
  }

  const parts = data?.candidates?.[0]?.content?.parts || [];
  const imgPart = parts.find(p => p.inlineData && p.inlineData.data);
  if (!imgPart) {
    const texte = parts.map(p => p.text).filter(Boolean).join(" ");
    return json(502, { ok: false, erreur: "pas_image_retournee", detail: texte || "Le modèle n'a renvoyé aucune image.", finishReason: data?.candidates?.[0]?.finishReason || "" });
  }

  return json(200, { ok: true, image: imgPart.inlineData.data, mimeType: imgPart.inlineData.mimeType || "image/png" });
};

// Protection anti-abus : jeton d'accès obligatoire (ci-dessus) + limite de débit native Netlify
// en second rempart. 5 appels/heure/IP — largement suffisant pour un usage de test personnel ;
// à revoir si cet endpoint est un jour ouvert au grand public depuis l'app principale.
export const config = { path: "/api/stylize", rateLimit: { windowLimit: 5, windowSize: 3600, aggregateBy: ["ip"] } };
