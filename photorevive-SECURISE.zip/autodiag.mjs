// Happi-El PhotoRevive — sonde de diagnostic (lecture seule, aucune donnée sensible complète exposée)
// Ouvrir simplement /api/autodiag dans un navigateur : page HTML lisible, pas de JSON à interpréter.
const BASE = process.env.AIRTABLE_BASE_ID;
const TOKEN = process.env.AIRTABLE_TOKEN;
const CODE_TEST = "PR-EJBD-Q9HN";

const masque = (v) => (v ? `${v.slice(0, 4)}…${v.slice(-4)} (${v.length} caractères)` : "ABSENTE");

function page(lignes, verdict) {
  const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Diagnostic PhotoRevive</title>
  <style>
    body{font-family:-apple-system,system-ui,sans-serif;background:#0b0d12;color:#e8e8ec;padding:20px;line-height:1.5}
    h1{font-size:1.2rem;color:#fff}
    .verdict{padding:14px;border-radius:10px;margin:16px 0;font-weight:600;font-size:1.05rem}
    .ok{background:#12321f;color:#5fe08a;border:1px solid #1f5c38}
    .fail{background:#3a1414;color:#ff8a8a;border:1px solid #6b1f1f}
    .ligne{padding:10px 0;border-bottom:1px solid #23262f;display:flex;gap:10px}
    .etat{font-size:1.1rem}
    code{background:#181b22;padding:2px 6px;border-radius:4px;font-size:0.85rem;word-break:break-all}
  </style></head><body>
  <h1>🔍 Diagnostic PhotoRevive — accès Airtable</h1>
  <div class="verdict ${verdict.ok ? "ok" : "fail"}">${verdict.texte}</div>
  ${lignes.map(l => `<div class="ligne"><span class="etat">${l.ok ? "✅" : "❌"}</span><div><strong>${l.titre}</strong><br><code>${l.detail}</code></div></div>`).join("")}
  <p style="margin-top:20px;color:#888;font-size:0.85rem">Faites une capture d'écran de cette page entière et envoyez-la telle quelle.</p>
  </body></html>`;
  return new Response(html, { status: 200, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store, no-cache, must-revalidate" } });
}

export default async () => {
  const lignes = [];

  lignes.push({ ok: !!BASE, titre: "Variable AIRTABLE_BASE_ID présente", detail: BASE || "ABSENTE — non définie sur ce site Netlify" });
  lignes.push({ ok: !!TOKEN, titre: "Variable AIRTABLE_TOKEN présente", detail: masque(TOKEN) });

  if (!BASE || !TOKEN) {
    return page(lignes, { ok: false, texte: "❌ ARRÊT : une variable d'environnement manque sur CE site Netlify précis (photorevive-ai). Si vous les avez ajoutées, vérifiez que c'était bien sur ce site et non sur happi-el-consulting, puis redéployez." });
  }

  let r, texteErreur = "";
  try {
    const url = `https://api.airtable.com/v0/${BASE}/Codes?filterByFormula=${encodeURIComponent(`UPPER({Code})="${CODE_TEST}"`)}&maxRecords=1`;
    r = await fetch(url, { headers: { Authorization: "Bearer " + TOKEN } });
  } catch (e) {
    lignes.push({ ok: false, titre: "Appel réseau vers Airtable", detail: "Échec : " + (e && e.message || "erreur inconnue") });
    return page(lignes, { ok: false, texte: "❌ ARRÊT : le serveur Netlify n'arrive pas du tout à joindre Airtable." });
  }

  let corps;
  try { corps = await r.json(); } catch { corps = null; }

  lignes.push({ ok: r.ok, titre: `Réponse Airtable (statut HTTP ${r.status})`, detail: r.ok ? "OK" : JSON.stringify(corps || {}).slice(0, 300) });

  if (!r.ok) {
    let cause = "Cause inconnue, voir le détail brut ci-dessus.";
    if (r.status === 401 || r.status === 403) cause = "Le jeton AIRTABLE_TOKEN est invalide, expiré, ou n'a plus la permission sur cette base précise.";
    if (r.status === 404) cause = "La base ou la table 'Codes' est introuvable avec cet ID/jeton — vérifiez AIRTABLE_BASE_ID.";
    return page(lignes, { ok: false, texte: "❌ ARRÊT : Airtable a refusé la requête. " + cause });
  }

  const rec = corps.records && corps.records[0];
  lignes.push({ ok: !!rec, titre: `Enregistrement trouvé pour ${CODE_TEST}`, detail: rec ? rec.id : "Aucun enregistrement retourné (formule ou nom de table différent ?)" });

  if (!rec) {
    return page(lignes, { ok: false, texte: "❌ ARRÊT : la connexion à Airtable fonctionne, mais aucun enregistrement ne correspond — la table s'appelle peut-être différemment de 'Codes'." });
  }

  const f = rec.fields;
  lignes.push({ ok: true, titre: "Champs lus sur l'enregistrement", detail: `Quota=${f.Quota} · Utilise=${f.Utilise ?? 0} · Statut=${f.Statut} · Expire=${f.Expire}` });

  return page(lignes, { ok: true, texte: "✅ TOUT FONCTIONNE côté serveur : le jeton est valide, la base est jointe, le code est trouvé et valide. Si l'activation échoue quand même dans l'app, le problème est ailleurs (v. mon message)." });
};

export const config = { path: "/api/autodiag" };
