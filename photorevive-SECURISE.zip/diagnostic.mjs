// Happi-El PhotoRevive — diagnostic IA sécurisé
// La clé API reste sur le serveur (variable d'environnement ANTHROPIC_API_KEY).

const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5";
const MAX_B64 = 2_000_000;          // ~1,5 Mo d'image max
const PER_IP_PER_HOUR = Number(process.env.LIMITE_PAR_HEURE || 8);
const hits = new Map();              // limite simple par adresse IP (par instance)

const PROMPT = `Tu es l'expert restauration photo de Happi-El PhotoRevive (Cameroun). Examine cette photo.
Règles strictes : n'identifie jamais la personne, ne commente pas son physique ni sa beauté, ne suggère aucune modification des traits du visage. Le profil de carnation sert uniquement à calibrer le traitement.
Réponds uniquement avec ce JSON (français), sans texte autour :
{"etat":"phrase courte sur l'état général","score_degradation":0-100,"dommages":["liste courte : rayures, taches, jaunissement, grain, flou, déchirure, pli, surexposition, compression WhatsApp…"],"epoque_estimee":"ex. années 1970, tirage studio","type":"portrait|groupe|cérémonie|paysage|autre","carnation":"foncée|médiane|claire|mixte|non visible","reglages":{"dust":0-100,"denoise":0-100,"color":0-100,"clarity":0-100,"skin":0-100,"glow":0-100,"sharp":0-100},"rendu":"auto|nb|sepia","cadre":"studio|galerie|ndop|toghu|prestige|hommage","legende":"légende courte, chaleureuse, sans nom propre inventé","limites":"ce que la restauration automatique ne pourra pas réparer, ou chaîne vide"}
Pour une peau foncée, garde skin >= 80 et glow modéré pour ne jamais éclaircir le teint.
Règle absolue sur le grain de peau : ne recommande JAMAIS un denoise supérieur à 55 sur un portrait, même très abîmé — au-delà, la peau devient lisse et artificielle ("effet plastique"), ce qui est strictement interdit. Préfère un denoise modéré combiné à un dust plus élevé pour traiter poussière/rayures sans jamais lisser la texture naturelle du visage. Le respect de l'identité faciale et de la texture de peau réelle prime toujours sur l'agressivité du nettoyage.`;

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store, no-cache, must-revalidate" } });

export default async (req, context) => {
  if (req.method !== "POST") return json(405, { error: "methode" });
  if (!process.env.ANTHROPIC_API_KEY) return json(500, { error: "cle_api_absente" });

  const ip = context.ip || req.headers.get("x-nf-client-connection-ip") || "inconnu";
  const now = Date.now();
  const list = (hits.get(ip) || []).filter(t => now - t < 3_600_000);
  if (list.length >= PER_IP_PER_HOUR) return json(429, { error: "trop_de_demandes" });
  list.push(now); hits.set(ip, list);

  let body;
  try { body = await req.json(); } catch { return json(400, { error: "json" }); }
  const image = typeof body?.image === "string" ? body.image : "";
  if (!image || image.length > MAX_B64 || !/^[A-Za-z0-9+/=]+$/.test(image)) return json(400, { error: "image" });

  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1000,
      messages: [{ role: "user", content: [
        { type: "image", source: { type: "base64", media_type: "image/jpeg", data: image } },
        { type: "text", text: PROMPT }
      ] }]
    })
  });
  if (!r.ok) return json(502, { error: "ia_indisponible", status: r.status });

  const data = await r.json();
  const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
  const m = text.replace(/```json|```/g, "").match(/\{[\s\S]*\}/);
  if (!m) return json(502, { error: "reponse_illisible" });
  try { return json(200, JSON.parse(m[0])); } catch { return json(502, { error: "reponse_illisible" }); }
};

export const config = { path: "/api/diagnostic" };
